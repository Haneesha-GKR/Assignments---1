-----------------------------------------------------
=== Assignement 1: Machine Learning ===
-----------------------------------------------------
Name: Haneesha Gurugubelli,Sneha Nandigala
Email: hxg170830@utdallas.edu,sxn171430@utdallas.edu
NetID: hxg170830,sxn171430

Requires Python 3.0 and above

Requires psykit and pandas libraries

There are 3 text files available:

1. README.txt: This file contains installation and results data.
2. RESULTS.txt contains the detailed results of the Text classification on textTrain and carTrain datasets
3. The data set is contained in data folder

-----------------------------------------------------
== USAGE: HOW TO RUN THE PROGRAM ==
-----------------------------------------------------


1.use command line and execute using python3 with textTrainData.py and carTrainData.py





