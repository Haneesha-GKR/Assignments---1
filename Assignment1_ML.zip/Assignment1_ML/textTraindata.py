
# coding: utf-8

# In[63]:


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
import re
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import CountVectorizer
from nltk.corpus import stopwords
import sklearn.linear_model as lm


# In[64]:


# First we read in the text train data into the dataset and test data into testset
dataset = pd.read_csv("textTrainData.txt", sep='\t', encoding='latin1')
testset = pd.read_csv("textTestData.txt", sep='\t', encoding='latin1')


# In[65]:


# Headers 
headers1 = ["Sentence", "Sentiment"]
headers2 = ["Sentence", "Sentiment"]


# In[66]:


dataset["Sentence"] = dataset["Sentence"].apply(lambda x: re.sub('([0-9]+:[0-9]+)','',x))
dataset["Sentence"]  = dataset["Sentence"] .apply(lambda x: re.sub('[^a-zA-Z]', ' ', x))
dataset["Sentence"]  = dataset["Sentence"] .apply(lambda x: x.lower())


# In[67]:


testset["Sentence"] = testset["Sentence"].apply(lambda x: re.sub('([0-9]+:[0-9]+)','',x))
testset["Sentence"]  = testset["Sentence"] .apply(lambda x: re.sub('[^a-zA-Z]', ' ', x))
testset["Sentence"]  = testset["Sentence"] .apply(lambda x: x.lower())


# In[68]:


#This is to convert train data sentence into numbers
vectorizer = CountVectorizer(stop_words = None)
trained_model = vectorizer.fit_transform(dataset["Sentence"])
trained_model = trained_model.toarray() 


# In[69]:


#This is to convert test data sentence into numbers
vectorizer = CountVectorizer(stop_words = None)
test_model = vectorizer.fit_transform(testset["Sentence"])
test_model = test_model.toarray() 


# In[70]:


train_x, test_x, train_y, test_y = train_test_split(train_data_features,dataset["Sentiment"], test_size=0.25, random_state=0)


# In[71]:


#Logisitci classifier is used
Logistic = lm.LogisticRegression(solver = 'liblinear', random_state = None, multi_class = 'ovr') 
Logistic = Logistic.fit( train_x, train_y )
Logistic = Logistic.fit( test_x, test_y )


# In[72]:


#Predictions for traindataset
prediction1 = Logistic.predict(train_x)


# In[73]:


#Predictions for testdataset
prediction2 = Logistic.predict(test_x)


# In[74]:


#Confusion matrix for traindata
print( " Confusion matrix ",confusion_matrix(train_y, prediction1))


# In[75]:


#Confusion matrix for testdata
print( " Confusion matrix ",confusion_matrix(test_y, prediction2))


# In[76]:


#Accuracy for train data
print(accuracy_score(train_y, prediction1))


# In[77]:


#Accuracy for test data
print(accuracy_score(test_y, prediction2))

