
# coding: utf-8

# In[15]:


# Required Python Packages
import pandas as pd
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix


# In[16]:


# Here we have to load the given car Train Data into dataset and test data into testdata using read
dataset = pd.read_csv("carTrainData.csv")
testset = pd.read_csv("carTestData.csv")


# In[17]:


# headers 
headers1 = ["V1", "V2", "V3", "V4", "V5", "V6", "V7"]
headers2 = ["V1", "V2", "V3", "V4", "V5", "V6", "V7"]


# In[18]:


# Add the headers to the columns of the loaded dataset and testset
dataset.columns = headers1
testset.columns = headers2


# In[19]:


#To check to which datatype each column belongs to
dataset.dtypes


# In[20]:


testset.dtypes


# In[21]:


#We got to know that each column belongs to an object which is a categorical variables(called strings in simple terminology)
#while using any of the classifiers, we have to fit the the values to it i.e., we have to use fit function but fit will not work for string values
#so we have to convert all the strings to numbers to deal with any classifier
#To convert to number we use encoding concept
#Here all columns are converted to numbers
number = preprocessing.LabelEncoder()
for i in headers1:
    dataset[i] = number.fit_transform(dataset[i].astype("str"))



# In[22]:


# For test data
number = preprocessing.LabelEncoder()
for i in headers2:
    testset[i] = number.fit_transform(testset[i].astype("str"))


# In[23]:


#check if everything is converted to numbers or not
dataset.head(20)


# In[24]:


#check if everything is converted to numbers or not
testset.head(20)


# In[25]:


print(dataset.describe())


# In[26]:


print(testset.describe())


# In[34]:


# Split dataset into train and test dataset
#train_x, test_x, train_y, test_y = train_test_split(dataset[headers[1:-1]], dataset[headers[-1]],
#                                                        train_size=0.7)
train_x, train_y = dataset[headers1[1:-1]], dataset[headers1[-1]]
test_x, test_y = testset[headers2[1:-1]], testset[headers2[-1]]


# In[35]:


# Here we create the Random Forest Classifier
clf = RandomForestClassifier()
trained_model = clf.fit(train_x, train_y)
test_model = clf.fit(test_x, test_y)


# In[29]:


# Check accuracy on train set
predictions1 = trained_model.predict(train_x)


# In[30]:


# Check accuracy on test set
predictions2 = test_model.predict(test_x)


# In[31]:


#Train accuracy and test accuracy
print( "Train Accuracy :: ", accuracy_score(train_y, trained_model.predict(train_x)))
print( "Test Accuracy  :: ", accuracy_score(test_y, predictions2))


# In[32]:


#confusion matrix on train data
print( "Confusion matrix ", confusion_matrix(train_y, predictions1))


# In[33]:


#confusion matrix on test data
print( "Confusion matrix ", confusion_matrix(test_y, predictions2))

